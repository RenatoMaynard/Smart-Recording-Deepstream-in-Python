/*
 * SPDX-FileCopyrightText: Copyright (c) 2021-2022 NVIDIA CORPORATION & AFFILIATES.
 * All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include <gst/gst.h>
#include <glib.h>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <sys/timeb.h>
#include <functional>
#include <iostream>
#include <memory>
#include <optional>
#include <mutex>
#include <unordered_map>
#include <string>
#include <type_traits>

#include "gstnvdsmeta.h"
#include "nvdsmeta_schema.h"

#include <pybind11/cast.h>
#include <pybind11.h>

namespace py = pybind11;

/* ===== pydeepstream top-level helpers ===== */

namespace pydeepstream {
    // Rewriting ""_a operator from pybind11 namespace and putting it into pydeepstream namespace
    pybind11::arg operator ""_a(const char *str, size_t len);
}

namespace pydeepstream {
    void bindutils(py::module &m);
}

/* ===== utils (templates, helpers, storage) ===== */

namespace pydeepstream::utils {

    using COPYFUNC_SIG    = gpointer(gpointer, gpointer);
    using RELEASEFUNC_SIG = void(gpointer, gpointer);

    /**
     * Template for storing a std::function in a static storage unique to a given UniqueName.
     * Provides a C-compatible function pointer that calls the stored std::function.
     *
     * UniqueName  : const char* to a unique string literal identifying this storage
     * RetValue    : return type of the callable
     * ArgTypes... : argument types of the callable
     */
    template<const char *UniqueName, typename RetValue, typename... ArgTypes>
    struct function_storage {
    public:
        using function_type = std::optional<std::function<RetValue(ArgTypes...)>>;

        static void store(const function_type &f) {
            auto &inst = instance();
            const std::lock_guard<std::mutex> lock(inst.mut_);
            if (!inst.stopped_) {
                inst.fn_ = f;
            }
        }

        static void
        __attribute__((optimize("O0")))
        free_instance() {
            auto &inst = instance();
            const std::lock_guard<std::mutex> lock(inst.mut_);
            if (inst.fn_.has_value()) {
                inst.fn_.reset();
            }
            inst.stopped_ = true;
        }

        // Bridge function that the raw C function pointer will target.
        // Handles both void and non-void RetValue cleanly.
        static RetValue invoke(ArgTypes... args) {
            auto &inst = instance();
            const std::lock_guard<std::mutex> lock(inst.mut_);
            if (!inst.fn_.has_value() || !inst.fn_.value()) {
                if constexpr (std::is_void_v<RetValue>) {
                    return;
                } else {
                    return RetValue{};
                }
            }
            auto &fun = inst.fn_.value();
            if constexpr (std::is_void_v<RetValue>) {
                fun(std::forward<ArgTypes>(args)...);
                return;
            } else {
                return fun(std::forward<ArgTypes>(args)...);
            }
        }

        using pointer_type = decltype(&function_storage::invoke);

        static pointer_type get_ptr() { return &invoke; }

    private:
        static function_storage &instance() {
            static function_storage inst_;
            return inst_;
        }

        function_type fn_{};
        std::mutex    mut_{};
        bool          stopped_{false};
    };

    /**
     * Returns a C function pointer that forwards to the provided std::function,
     * storing the callable in the unique storage for UniqueName.
     */
    template<const char *UniqueName, typename RetValue, typename... ArgTypes>
    typename function_storage<UniqueName, RetValue, ArgTypes...>::pointer_type
    get_fn_ptr_from_std_function(const std::function<RetValue(ArgTypes...)> &f) {
        using storage = function_storage<UniqueName, RetValue, ArgTypes...>;
        storage::store(f);
        return storage::get_ptr();
    }

    /**
     * Frees the stored callable (so its destructor runs safely) and returns a null pointer.
     * The return value is not used by callers; returning nullptr satisfies the non-void type.
     */
    template<const char *UniqueName, typename RetValue, typename... ArgTypes>
    typename function_storage<UniqueName, RetValue, ArgTypes...>::pointer_type
    __attribute__((optimize("O0")))
    free_fn_ptr_from_std_function(const std::function<RetValue(ArgTypes...)> &f) {
        using storage = function_storage<UniqueName, RetValue, ArgTypes...>;
        (void)f;            // silence -Wunused-parameter
        storage::free_instance();
        return nullptr;     // satisfy non-void return type
    }

    // Is used to keep track of font names without duplicates. We need a char*
    // so we store stable buffers in shared_ptr<char>.
    extern std::unordered_map<std::string, std::shared_ptr<char>> font_name_memory;

    template<typename TYPE, typename FIELDTYPE>
    auto get_field_content_lambda(FIELDTYPE member) {
        return [member](TYPE *object) {
            return reinterpret_cast<size_t>((*object).*member);
        };
    }

    template<typename TYPE, typename FIELDTYPE>
    auto set_field_content_string_lambda(FIELDTYPE member) {
        return [member](TYPE *object, std::string str) {
            auto &map_str = font_name_memory;
            const auto it = map_str.find(str);
            if (it == map_str.end()) {
                auto tmp = std::shared_ptr<char>(
                    new char[str.size() + 1],
                    std::default_delete<char[]>());
                for (size_t i = 0; i < str.size(); ++i)
                    tmp.get()[i] = str[i];
                tmp.get()[str.size()] = '\0';
                map_str.emplace(str, std::move(tmp));
            }
            (*object).*member = map_str[str].get();
        };
    }

    /* Declarations used elsewhere */
    void set_copyfunc(NvDsUserMeta *meta,
                      std::function<COPYFUNC_SIG> const &func);

    void set_freefunc(NvDsUserMeta *meta,
                      std::function<RELEASEFUNC_SIG> const &func);

    void release_all_func();

    void generate_ts_rfc3339(char *buf, int buf_size);

} // namespace pydeepstream::utils

